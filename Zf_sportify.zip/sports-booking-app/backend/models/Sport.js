const mongoose = require('mongoose');

const SportSchema = new mongoose.Schema({
  name: { type: String, required: true },
  timeSlots: [
    {
      time: String,
      slotsFree: Number,
    },
  ],
});

module.exports = mongoose.model('Sport', SportSchema);
