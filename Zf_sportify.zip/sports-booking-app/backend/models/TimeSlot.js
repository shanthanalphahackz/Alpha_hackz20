const mongoose = require('mongoose');

const TimeSlotSchema = new mongoose.Schema({
  sportId: { type: mongoose.Schema.Types.ObjectId, ref: 'Sport' },
  time: String,
  slotsFree: Number,
});

module.exports = mongoose.model('TimeSlot', TimeSlotSchema);
