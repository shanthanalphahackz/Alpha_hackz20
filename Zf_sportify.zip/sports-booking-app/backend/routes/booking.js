const express = require('express');
const TimeSlot = require('../models/TimeSlot');
const router = express.Router();

// Book a slot
router.post('/', async (req, res) => {
  const { sportId, time, userId } = req.body;
  try {
    const slot = await TimeSlot.findOne({ sportId, time });
    if (slot.slotsFree > 0) {
      slot.slotsFree -= 1;
      await slot.save();
      res.json({ message: 'Booking successful', slot });
    } else {
      res.status(400).json({ message: 'No slots available' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
